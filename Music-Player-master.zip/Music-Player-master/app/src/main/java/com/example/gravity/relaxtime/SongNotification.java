package com.example.gravity.relaxtime;


import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.session.MediaSession;
import android.widget.RemoteViews;

public class SongNotification {

Context context;
MediaSession mediaSession;
public void SongNotification(){

    }


//    public void setNotification(){
//
  //      Notification notification=new NotificationCompat.Builder(context,"CHANNEL_ID")
//                .setSmallIcon(R.drawable.splash)
//                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
//
//                .addAction(R.drawable.ic_chevron_left_black_24dp,"Previous",previousPendingIntent)
//                .addAction(R.drawable.ic_pause_black_24dp,"Pause",pausePendingIntent)
//                .addAction(R.drawable.ic_chevron_right_black_24dp,"Next",nextPendingIntent)
//                .setStyle(new Notification.MediaStyle()
//                         .setShowActionsInCompactView(1)
//                        .setMediaSession(mediaSession.getSessionToken()))
//                .setContentTitle("Current Song")
//                .setContentText("My Awesome Band")
//                .build();
//    }

}
