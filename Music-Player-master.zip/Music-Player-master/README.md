# Music-Player
(Date-- July 2022)
A simple light weight size around 2 MB music player named SOUL FUSION.

Build in android.



Dependecies used
> 'com.github.mancj:MaterialSearchBar:0.7.6'
-- for material search bar--

>'com.squareup.picasso:picasso:2.5.2'
--Picture library--

>'android.arch.navigation:navigation-fragment:1.0.0-alpha04'
--A beautiful navigation view--

Note: These library may be deprecated by now.
